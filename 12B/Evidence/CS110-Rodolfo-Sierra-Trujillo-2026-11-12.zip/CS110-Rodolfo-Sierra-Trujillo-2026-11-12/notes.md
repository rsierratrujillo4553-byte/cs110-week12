# Rodolfo Sierra-Trujillo

# prep
repo: https://github.com/rsierratrujillo4553-byte/cs110-week12
video1: Game Development Pipeline – Introduction Notes

Topic: Introduction to Game Development Pipeline

1. What Is a Game Development Pipeline?
- A game development pipeline is a step-by-step process used to create a video game.
- It helps developers stay organized and understand what needs to be done.
- The pipeline covers mindset, folder structure, documentation, and game development tools.
- Following a pipeline makes the development process easier to manage.

2. Mindset in Game Development
- Having the right mindset is important when developing games.
- A growth mindset helps developers learn from mistakes and improve their skills.
- Game development can be challenging, so staying motivated and focused is important.
- Developers need to learn how to overcome obstacles instead of giving up.
- Having patience and being willing to learn can help throughout development.

3. Creating a Folder Structure
- A folder structure helps keep project files organized.
- It makes it easier to find assets, scripts, and documents.
- Different projects may need different folder structures.
- Having organized folders makes development easier.
- Folder structures can also be used for projects outside of game development.

4. Game Development Documentation
- Documentation helps developers keep track of their projects.
- Important documents include:
  - Game Development Documents (GDD)
  - Task lists
  - README files
  - Project notes
- Documentation should be stored in the correct folders.
- Documentation is considered a living document because it changes as the project develops.
- Keeping documentation updated helps developers track progress and improvements.

5. Game Development Tools
- Developers use different tools to create games.
- Some important tools include:
  - IDEs (Integrated Development Environments)
  - Text editors
  - Photo editors
  - 3D editors
  - Game development environments
- Developers need to know where to find and download assets.
- Tools need to be installed and configured correctly.
- The tools used depend on the project and development pipeline.

6. The Four Parts of the Tutorial Series

Video 1: Mindset
- Understanding why mindset matters.
- Developing a growth mindset.
- Overcoming challenges.
- Staying motivated and focused.

Video 2: Folder Structure
- Understanding why folder structures are important.
- Creating folders based on project needs.
- Organizing scripts, assets, and documents.
- Using folder structures for different projects.

Video 3: Documentation
- Understanding why documentation matters.
- Creating game development documents.
- Making task lists and README files.
- Updating documentation throughout development.

Video 4: Game Development
- Finding and downloading assets.
- Choosing development tools.
- Installing and configuring software.
- Using tools to improve the development process.

7. Key Takeaways
- Game development requires planning and organization.
- Having a growth mindset helps developers overcome challenges.
- Folder structures make files easier to manage.
- Documentation should be updated as the project grows.
- Choosing the right tools can make development easier.
- Following a pipeline helps developers complete projects step by step.

8. What I Learned
I learned that game development is more than just writing code. There are different steps that help make the process easier and more organized. Having the right mindset, organizing files, creating documentation, and using the right tools are all important parts of developing a game. I also learned that documentation should be updated as the project grows. Following a game development pipeline can help me stay organized when I start creating my own games.
video2: Game Development Pipeline – Mindset Notes

Topic: The Importance of Mindset in Game Development

1. Why Is Mindset Important in Game Development?
- Having the right mindset is important for becoming a successful game developer.
- A positive mindset helps developers stay creative, motivated, and focused.
- Game development takes time, patience, and teamwork.
- The five important parts of mindset are creativity, perseverance, adaptability, collaboration, and customer focus.

2. Creativity and Innovation
- Game development requires creativity and new ideas.
- Developers should learn to think both inside and outside the box.
- Existing ideas can be improved to create something new.
- A positive mindset encourages developers to experiment and be creative.

3. Perseverance
- Developing a game can be a long and challenging process.
- Developers need to stay motivated even when things become difficult.
- Perseverance helps developers continue working toward their goals.
- Team members should encourage each other throughout development.

4. Adaptability
- The gaming industry is constantly changing.
- New technologies, trends, and development tools are always being introduced.
- Developers need to be willing to learn and adapt.
- Being adaptable helps developers create games that stay relevant and interesting.

5. Collaboration
- Game development involves working with different people and tools.
- Programmers, artists, designers, and other team members work toward the same goal.
- Even independent developers use tools and game engines created by others.
- Good communication and teamwork can improve the development process.
- Collaboration helps developers solve problems and create better games.

6. Customer Focus
- Games are created for players and fans.
- Developers should think about what players want and enjoy.
- Creating an engaging and enjoyable experience is important.
- Understanding the target audience can help make a game successful.
- Even when creating a game for yourself, you are still creating it for a player.

7. How to Develop a Growth Mindset
- A growth mindset means believing that skills and abilities can improve through learning and effort.
- Developers should focus on their potential instead of only their current abilities.
- Developing a growth mindset takes time and practice.

Ways to develop a growth mindset:

1. Embrace Challenges
   - Challenges are opportunities to learn.
   - Try new projects even when they seem difficult.
   - Learning new skills helps developers improve.

2. Learn From Failures
   - Making mistakes is a normal part of development.
   - Developers should use failures to understand what went wrong.
   - Bugs and errors can help developers learn how to improve their games.
   - Testing and fixing problems are important parts of development.

3. Focus on Effort
   - Skills are not fixed and can improve over time.
   - Hard work and dedication help developers reach their goals.
   - Progress comes from continuing to practice and learn.

4. Be Open to Feedback
   - Feedback helps developers understand what they can improve.
   - Constructive criticism should be used as an opportunity to learn.
   - Listening to others can improve a developer's skills.

5. Surround Yourself With Positive Role Models
   - Learning from experienced people can help developers grow.
   - Positive role models can provide motivation and guidance.
   - Working with people who have a growth mindset can encourage improvement.

6. Keep Learning
   - Game developers should always be willing to learn new things.
   - New knowledge and experiences help improve development skills.
   - Developing a growth mindset is a continuous process.

8. Common Obstacles in Game Development

Technical Challenges
- Game development requires programming, graphic design, sound engineering, and other technical skills.
- Common problems include bugs, compatibility issues, hardware limitations, and coding errors.
- Developers can overcome these challenges through testing and teamwork.
- Keeping API documentation and other references organized makes troubleshooting easier.

Scope Creep
- Scope creep happens when developers keep adding features beyond the original plan.
- Adding too many features can make a project difficult to finish.
- Scope creep can cause delays, increased costs, and burnout.
- Developers should create a clear plan and follow their Game Development Document (GDD).
- The original goals should be completed before expanding the project.

Marketing and Distribution
- Creating a game is only one part of the process.
- Developers also need to know how to reach their target audience.
- Marketing helps people learn about the game.
- Distribution involves getting the game to players.
- Developers should create marketing and distribution plans early.

Funding
- Developing games can become expensive depending on the size of the project.
- Independent developers may have difficulty finding funding.
- A business plan and pitch deck can help explain the project to potential supporters.
- Possible funding options include grants, crowdfunding, partnerships, and publishers.

Burnout and Mental Health
- Game development can become stressful and demanding.
- Working too much without breaks can lead to burnout.
- Developers should maintain a healthy balance between work and personal life.
- Taking breaks and getting enough rest can help maintain focus.
- Community support and communication can help developers manage challenges.

9. How to Stay Motivated and Focused

Set Goals and Create Task Lists
- Clear goals help developers understand what needs to be completed.
- Large goals should be divided into smaller tasks.
- Each task should have a deadline.
- Checking progress regularly helps keep the project on schedule.

Celebrate Small Wins
- Completing smaller tasks is still important progress.
- Small victories help developers stay motivated.
- Progress can happen through coding, artwork, music, or documentation.
- Celebrating milestones encourages the team to keep working.

Take Breaks
- Regular breaks help prevent burnout.
- Getting enough sleep is important for staying focused.
- Developers
video3: Game Development Pipeline – Folder Structure Notes

Topic: Developing a Solid Folder Structure

1. Why Is a Folder Structure Important?
- A folder structure helps developers organize their game projects.
- It makes managing files, documents, and assets easier.
- Team members can quickly understand where everything is located.
- Organized folders improve collaboration and efficiency.
- A good folder structure makes it easier for new team members to understand the project.
- Developers should plan their folder structure before starting development.

2. Planning a Folder Structure
- Every project should have a main folder.
- The main folder should be named after the game or project.
- Developers should decide how to name and organize files.
- It is important to plan where documents, scripts, and assets will be stored.
- Developers should also think about how they will back up their files.
- Planning the structure on paper first can help prevent confusion.

3. Creating Folders in Windows
- Open File Explorer.
- Navigate to the location where the project will be stored.
- Create a new folder for the game.
- Name the folder after the project.

Ways to create a new folder:
- Right-click and select New → Folder.
- Use the New Folder button in File Explorer.
- Press Ctrl + Shift + N to create a folder quickly.

4. Creating a Project Log
- A project log is used to keep track of changes and progress.
- It helps developers remember what they worked on.
- Project logs can include dates, times, completed tasks, and updates.
- The instructor demonstrates creating a log using Windows Notepad.

Steps to create a project log:
1. Open the main project folder.
2. Right-click and select New → Text Document.
3. Name the file after the project, such as MyGameLog.txt.
4. Open the file in Notepad.
5. Type `.LOG` at the beginning of the file.
6. Save and close the document.
7. Reopen the file to automatically add the current date and time.
8. Write down what was completed during development.

**Example Log Entry:**

Date: 11/10/2026

Project: My Game

Task Completed: Created the folder structure.

Notes: Organized the project folders and prepared the files for development.

5. Why Project Logs Are Useful
- Logs help developers track their progress.
- They provide a history of changes made to the project.
- Team members can review previous work.
- Logs help identify when tasks were completed.
- Keeping a log makes project management easier.

6. Using JSON to Create Folder Structures
- JSON stands for JavaScript Object Notation.
- JSON can be used to describe folders, files, and their contents.
- The instructor demonstrates a program that automatically creates folders using JSON.
- This saves time compared to creating every folder manually.
- Developers can customize the JSON file to match their project.

7. JSON Folder and File Maker
- The instructor created a tool called TLRA JSON Folder and FileMaker.
- The tool uses JSON files to generate project folders.
- It can create folders, text files, HTML files, and README files.
- The program allows developers to load examples and templates.
- Developers can edit the JSON to change folder names and file contents.
- The tool checks whether the JSON is valid before creating the folders.

Main features of the tool:
- Load Example: Opens an example JSON structure.
- Load Template: Opens an existing JSON template.
- Save JSON: Saves the JSON configuration.
- Check for Updates: Checks for newer versions.
- Make Folder: Opens the folder creation section.
- Run JSON: Creates the folders and files in the selected location.

8. Creating Folders With the JSON Tool
1. Open the JSON Folder and FileMaker application.
2. Select Load Example or Load Template.
3. Choose the JSON file.
4. Change the main folder name to the name of the game.
5. Review the folders and files in the JSON.
6. Make any necessary changes.
7. Select Make Folder.
8. Click Run JSON.
9. Choose where the project should be saved.
10. The program automatically creates the folder structure.

9. Game Development Document (GDD)
- A Game Development Document is used to plan the game.
- It acts as a blueprint for the development process.
- The instructor's tool can automatically create a GDD template.
- The template contains sections that help developers organize their ideas.
- Developers can change the document to match their own game.
- The document should be saved using the game's name.

10. Important Project Folders
- Context: Contains information about the project.
- Requirements: Contains the game's requirements, backstory, and concept.
- Resources: Contains useful links and project resources.
- Assets: Stores the files used to create the game.
- Audio: Stores music and sound effects.
- Images: Stores pictures and graphics.
- Models: Stores 3D models.
- Export Projects: Stores exported project files.
- Study: Contains learning materials and references.
- Unity Project: Contains the Unity game project.

11. README Files
- README files explain what a folder or project contains.
- They help developers understand where files belong.
- README files can provide instructions for using project resources.
- They make it easier for new team members to understand the folder structure.
- The instructor demonstrates using text and HTML files for documentation.

12. Game Development Resources
The instructor mentions several tools that can be used during development.

- Unity: A game engine used to create games.
- Blender: A program used for 3D modeling.
- Notepad++: A text editor for writing and editing files.
- Visual Studio: An IDE used for programming.
- Discord: A communication tool for collaboration.
- Free Audio Resources: Websites that provide sounds for games.
- W3Schools: A website for learning JSON and other programming topics.

13. Benefits of an Organized Project
- Files are easier to find.
- Developers save time.
- Team members can collaborate more efficiently.
- Documentation stays organized.
- Project changes are easier to track.
- New developers can understand the project faster.
- A clear structure reduces confusion.
- Developers can focus more on creating the game.

14. Key Takeaways
- Folder structures are an important part of game development.
- Developers should organize their projects before beginning development.
- Project logs help track progress and changes.
- JSON can be used to create folders and files automatically.
- README files explain the purpose of project folders.
- A Game Development Document helps plan the game.
- Organized projects make teamwork and development easier.
- Having a solid folder structure helps prepare developers for success.

15. What I Learned
I learned that having a good folder structure is important when developing a game because it keeps everything organized and easier to find. I also learned how to create folders using Windows shortcuts and how to make a project log to track my progress. Another thing I learned is that JSON can be used to automatically create folders and files instead of making everything manually. I think this is useful because it can save time when working on bigger projects. I also learned that README files and Game Development Documents help explain how a project works. I can use these ideas when organizing my own game projects so I can keep track of my files and make development easier.
video4: # Game Development Pipeline – Documentation Notes

**Topic: Creating and Organizing Game Development Documentation**

### 1. What Is Game Development Documentation?
- Documentation is used to organize and plan a game development project.
- It helps developers understand what needs to be completed.
- Documentation includes project information, requirements, resources, and tasks.
- It helps team members understand the game and its development process.
- Documentation should be organized and easy to share.

### 2. Game Development Document (GDD)
- A Game Development Document is used as a blueprint for creating a game.
- It can also be called a Game Design Document.
- The GDD contains important information about the game.
- Developers use it to understand the game's goals, story, and development requirements.
- Team members can refer to the GDD throughout development.

### 3. Customizing the Game Development Document
- The instructor uses a GDD template created in the previous lesson.
- The template contains different sections that need to be completed.
- Developers should change the title to match their game.
- The subtitle should describe the project.
- The title image can be replaced with an image representing the game.
- Unnecessary information can be removed from the template.
- Important sections should be kept and customized.

**Steps to customize the GDD:**
1. Open the Game Development Document.
2. Change the title to the name of the game.
3. Update the subtitle.
4. Replace the title image when one is available.
5. Read through the document sections.
6. Remove information that is not needed.
7. Fill in the sections with information about the game.
8. Save the document and share it with team members.

### 4. Important Sections of a GDD
- Game Overview: Explains what the game is about.
- Game Title: The name of the game.
- Story and Backstory: Explains the game's setting and background.
- Game Concept: Describes the main idea of the game.
- Requirements: Lists what is needed to create the game.
- Art Resources: Identifies artwork and other visual resources.
- Team Members: Identifies people working on the project.
- Tasks: Lists responsibilities and work that needs to be completed.
- Milestones: Helps track important stages of development.
- Development Resources: Lists the tools and software used for the project.

### 5. Why the Story and Backstory Matter
- The story and backstory help explain the game's purpose.
- They give team members a better understanding of the project.
- Developers can refer to the story while creating the game.
- The story helps guide development decisions.
- Having this information documented keeps the project consistent.

### 6. README Files
- README files explain what a folder contains.
- They help developers understand where project files belong.
- Each folder created by the instructor's tool includes a README file.
- README files are useful when new team members join a project.
- Developers should read the README files before adding content to folders.

### 7. Project Folder Structure
- The instructor uses the folder structure created in the previous lesson.
- Each folder has a specific purpose.
- The folders help organize documentation, assets, and resources.

**Important project folders:**
- Context: Contains information about the project.
- Game Project: Stores the game development project.
- Requirements: Contains the game's concepts, backstory, and requirements.
- Resources: Contains useful links and development tools.
- Assets: Stores images, audio, and 3D models.
- Study: Contains documentation and learning resources.

### 8. Requirements Documentation
- Requirements explain what must be completed for the game.
- They help developers understand the project's goals.
- The instructor's requirements section includes the backstory, concepts, and requirements.
- Developers should replace the example information with their own.
- Requirements can be updated as development progresses.
- Keeping requirements organized helps developers follow the project plan.

### 9. Resources and Development Tools
- The Resources folder contains links to software and other development materials.
- These resources help developers prepare their development environment.

**Tools mentioned in the video:**
- Unity: Used for developing the game.
- Blender: Used for creating 3D models.
- Notepad++: Used for editing text files.
- Visual Studio: Used for programming.
- Microsoft Word: Used for creating documents.
- Microsoft Excel: Used for organizing information.
- Discord: Used for communication and collaboration.
- Free Audio Resources: Used for finding sounds for the game.

### 10. Project Log
- A project log records progress throughout development.
- Developers can use it to document completed tasks.
- Logs help track changes made to the project.
- The project log is stored with the project resources.
- Keeping a log makes it easier to review previous work.

### 11. Assets Folder
- The Assets folder stores the resources used to create the game.
- Assets can include 3D models, images, and audio files.
- Keeping assets organized makes them easier to locate.
- Developers can add new assets as the project grows.

### 12. Study Folder and API Documentation
- The Study folder contains learning materials and references.
- Developers can store links to documentation for the programs they use.
- API documentation helps developers understand how software tools work.
- The instructor includes references for Unity, Blender, Microsoft Word, and Microsoft PowerPoint.
- Additional documents and links can be added when needed.

### 13. Creating a Development Overview
- A development overview explains the main steps needed to complete the game.
- It gives team members a simple understanding of the project.
- The overview should be easy to read and follow.

**Example development overview:**
1. Download the applications needed for development.
2. Start the Unity project.
3. Download and load the game assets.
4. Create additional assets using Blender or a photo editor.
5. Write the code and develop the game.
6. Complete the development process.

### 14. Game Development Pipeline Steps

**Step 0: Create the Folder Structure**
- Organize the project folders and files.
- Prepare the documentation.
- Set up the project structure.

**Step 1: Gather Assets**
- Find and download the assets needed for the game.
- Organize images, audio, and models.

**Step 2: Set Up the Project**
- Open the game development environment.
- Create the game project.
- Prepare the project for development.

**Step 3: Create Assets**
- Create any additional artwork or models needed.
- Use Blender or a photo editor when necessary.

**Step 4: Program the Logic**
- Write the code that controls how the game works.
- Develop the game's features and functionality.

**Step 5: Test and Debug**
- Test the game to find problems.
- Fix errors and bugs.
- Make sure the game works correctly.

**Step 6: Publish the Game**
- Prepare the completed game for release.
- Publish the game so players can access it.

### 15. Why Documentation Is Important
- Documentation helps developers stay organized.
- It gives team members a clear understanding of the project.
- It explains the game's story, requirements, and development process.
- It makes it easier for new team members to join.
- It provides references for tools and resources.
- It helps developers follow the original plan.
- It acts as a blueprint throughout development.

### 16. Key Takeaways
- A Game Development Document is an important part of planning a game.
- The GDD should be customized to match the project.
- The game's story and backstory should be documented.
- README files help explain the purpose of project folders.
- Requirements help developers understand what needs to be completed.
- The Resources folder contains useful development tools and links.
- The Assets folder stores images, audio, and models.
- The Study folder contains API documentation and references.
- A development overview helps explain the main project goals.
- Following the development pipeline keeps the project organized.

### 17. What I Learned
I learned that documentation is an important part of game development because it helps keep everything organized and gives developers a clear plan to follow. I learned that a Game Development Document works like a blueprint for the game and includes information such as the story, requirements, tasks, and resources. I also learned that README files help explain what each folder is used for, which makes it easier to find files and work with other people. Another thing I learned is that having a development overview helps break the project into steps, from gathering assets to testing and publishing the game. I can use this when creating my own games so I can stay organized and keep track of what I need to finish.
video5: # Game Development Pipeline – Introduction to Unity Notes

**Topic: Setting Up Unity and Learning the Unity Interface**

### 1. Introduction to Unity
- Unity is a game development engine used to create video games.
- In this lesson, the instructor begins creating the game using Unity.
- The game being developed is called "Tale of the Temper."
- The instructor previously created the folder structure and Game Development Document (GDD).
- The game's story and setting have already been added to the GDD.
- The game mechanics will be documented as development continues.

### 2. Preparing the Unity Project
- Before starting, developers should have an organized project folder.
- The Unity project should be saved inside the main project folder.
- The instructor creates a folder named after the game.
- Keeping the Unity project in the correct location helps maintain organization.

**Steps to prepare the project:**
1. Open the main project folder.
2. Find the folder where the Unity game will be stored.
3. Create a folder named after the game.
4. Open Unity Hub.
5. Prepare to create a new Unity project.

### 3. Creating a New Unity Project
- The instructor uses Unity version 2021.3.21f1.
- Other Unity versions may also work with the tutorial.
- Unity Hub is used to create and manage Unity projects.
- The instructor chooses the Third Person Core template.
- Templates provide a starting point instead of creating everything from scratch.

**Steps to create a Unity project:**
1. Open Unity Hub.
2. Select New Project.
3. Enter the game's name.
4. Choose the project location.
5. Select the Third Person Core template.
6. Download the template if necessary.
7. Click Create Project.
8. Wait for Unity to finish loading.

### 4. Why Use the Third Person Core Template?
- The template provides a playable character.
- It already includes basic character movement.
- Developers can begin testing the game immediately.
- It saves time because developers do not have to create everything from scratch.
- The template allows developers to focus on adding their own features and learning programming.

### 5. Fixing Unity Project Creation Errors
- Errors can happen when creating a Unity project.
- One issue demonstrated in the video involves a project file path that is too long.
- Long folder paths can cause problems when Unity extracts project files.
- Another possible issue is not having enough storage space.

**Steps to fix the folder path issue:**
1. Close or cancel the project creation process.
2. Open File Explorer.
3. Find the project folder that caused the error.
4. Delete the incomplete project folder if it is not needed.
5. Move the main project folder to a shorter location.
6. Open Unity Hub again.
7. Remove the old project entry from Unity Hub.
8. Create a new project using the shorter folder path.

**Important Note:**
- Removing a project from Unity Hub does not delete the actual project files.
- The instructor moves the project closer to the root of the drive to shorten its file path.

### 6. Understanding the Unity Interface
- Unity has several windows and tabs used for game development.
- These windows help developers manage objects, files, and game settings.
- The layout can be customized by dragging and rearranging tabs.

**Main Unity windows:**
- Hierarchy
- Scene View
- Game View
- Inspector
- Project Window

### 7. Hierarchy Window
- The Hierarchy displays the objects inside the current scene.
- Developers can select objects from the Hierarchy.
- Selecting an object allows developers to inspect or modify it.
- The Hierarchy helps developers understand what objects exist in the scene.

### 8. Scene View
- The Scene View is where developers work on the game environment.
- Developers can select and inspect objects in the scene.
- The Scene View allows developers to move around the environment.
- It is one of the main areas used when building a game.

### 9. Game View
- The Game View shows what the game looks like when it is running.
- Developers can use it to test gameplay.
- The Game View can be placed beside the Scene View.
- Having both views visible can make development easier.

### 10. Inspector Window
- The Inspector displays information about the selected object.
- The information changes depending on what is selected.
- Developers can view the components and properties of objects.

**Examples of information shown in the Inspector:**
- Transform
- Mesh Collider
- Mesh Renderer
- Materials
- Tags
- Layers

### 11. Project Window
- The Project Window displays the project's files and folders.
- It helps developers access assets, scenes, scripts, and other resources.
- Developers can open folders to view their contents.
- The Assets folder is one of the main folders used during development.
- The Packages folder contains package-related resources.

### 12. Navigating the Unity Scene
- Learning how to move around the Scene View is important.
- Navigation helps developers work faster and inspect objects.

**Scene navigation controls:**
- Mouse Scroll Wheel: Zoom in and out.
- Alt + Left Mouse Button: Rotate around the scene.
- Alt + Right Mouse Button and Move Mouse: Zoom in and out.
- Alt + Middle Mouse Button: Pan around the scene.
- F Key: Focus the camera on the selected object.

### 13. Using the Focus Shortcut
- The F key focuses the Scene View on a selected object.
- Developers can select an object in the Scene View or Hierarchy.
- Pressing F moves the view toward that object.
- This shortcut is useful for quickly finding objects in large environments.
- The instructor recommends practicing navigation before beginning programming.

### 14. Testing the Game
- The Third Person Core template already includes a playable character.
- Developers can test the game by clicking the Play button.
- The character can move, run, and jump.
- Testing the template helps developers understand the controls.

**Game Controls:**
- W: Move Forward
- A: Move Left
- S: Move Backward
- D: Move Right
- Mouse: Rotate the Camera
- Shift: Run
- Spacebar: Jump
- Escape: Release the Mouse Cursor

### 15. Starting and Stopping the Game
1. Open the Unity project.
2. Click the Play button.
3. Use the movement controls to move the character.
4. Test running and jumping.
5. Press Escape to release the mouse cursor.
6. Click Play again to stop the game.

### 16. Planning the Next Development Steps
- The instructor wants to build the game using the existing template.
- The goal is to complete a playable project.
- New features will be added when they are needed.
- Programming will be introduced as development continues.
- The next lesson will focus on changing the playable character.
- Developers may download a character model or create their own.
- Downloaded characters can also be modified to make them unique.

### 17. Key Takeaways
- Unity Hub is used to create and manage Unity projects.
- The instructor uses Unity 2021.3.21f1.
- The Third Person Core template provides a playable starting point.
- Organized project folders make development easier.
- Shorter file paths can help avoid certain project creation errors.
- The Hierarchy shows objects in the scene.
- The Scene View is used to work on the environment.
- The Game View shows the game while it is running.
- The Inspector displays object properties.
- The Project Window contains the game's files and assets.
- Learning navigation shortcuts can improve development speed.
- Testing the game helps developers understand how it works.
- The next step is customizing the playable character.

### 18. What I Learned
I learned how to create a Unity project and how to use the basic parts of the Unity interface. I learned that Unity Hub helps manage projects and that using a template can make development easier because it already includes features like character movement. I also learned that having a shorter folder path can help prevent errors when creating a project. Another thing I learned is what the Hierarchy, Scene View, Game View, Inspector, and Project Window are used for. I think learning how to navigate the Scene View is important because it makes working with objects easier. I can use what I learned when creating my own games and adding new features to them.
video6: # Game Development Pipeline – Importing a Custom Player Notes

**Topic: Importing a Custom Character and Working With Prefabs in Unity**

### 1. Introduction to Custom Characters
- In the previous lesson, we created a Unity project using the Third Person Core template.
- The template already includes a playable character.
- In this lesson, we learn how to replace the default character with a custom character.
- We can download a character or create our own.
- Using a custom character helps make the game more original.

### 2. Downloading a 3D Character
- The instructor uses Mixamo to find a 3D character.
- Mixamo provides characters and animations that can be used in Unity.
- The instructor also provides character resources through Google Drive.
- We can choose a character that fits our game.

**Steps to download a character:**
1. Open the Mixamo website.
2. Select the Characters section.
3. Browse the available characters.
4. Click on a character to preview it.
5. Use the mouse to rotate and inspect the character.
6. Click Download.
7. Find the downloaded character file on the computer.
8. Prepare to import the character into Unity.

### 3. Why Organizing Unity Assets Is Important
- Unity stores game resources inside the Assets folder.
- Having too many files in one folder can make the project confusing.
- The instructor recommends creating a folder named after the game or company.
- This helps separate our own assets from downloaded packages.
- Organized folders make it easier to find scripts, models, animations, and sounds.

### 4. Creating Folders in Unity
- Unity allows developers to create folders directly inside the Project Window.
- Folders can also be created using Windows File Explorer.
- The instructor recommends organizing assets before importing too many files.

**Steps to create a folder:**
1. Open Unity.
2. Find the Assets folder in the Project Window.
3. Right-click inside the folder.
4. Select Create → Folder.
5. Name the folder.
6. Open the folder and create additional folders as needed.

**Examples of folders:**
- Art
- Audio
- Materials
- Meshes
- Prefabs
- Scripts
- Scenes

### 5. Using the JSON Folder Maker
- The instructor uses the Tulstra JSON Folder and File Maker.
- This application automatically creates folders using a JSON template.
- It saves time because developers do not have to create every folder manually.
- The template is designed for organizing Unity projects.

**Steps to use the folder maker:**
1. Open the Tulstra JSON Folder and File Maker.
2. Find the Unity project folder template.
3. Copy the JSON template.
4. Open Notepad.
5. Paste the JSON into the document.
6. Save the file with a `.json` extension.
7. Open the JSON Folder Maker.
8. Select Load Template.
9. Choose the JSON file.
10. Make sure the program says the JSON format is valid.
11. Select Make Folder.
12. Click Run JSON.
13. Choose the Unity Assets folder as the destination.
14. Run the tool to create the folders.

### 6. Checking the Folder Structure
- After running the JSON tool, the folders appear in Unity.
- The instructor renames the main folder to match the game.
- The generated folders can store different types of assets.
- Existing folders, such as Scenes, can be moved into the game's main folder.
- Keeping everything organized makes the project easier to manage.

### 7. Importing the Character Into Unity
- The instructor downloads a character named Erica Archer.
- The character is imported as a 3D model file.
- The character should be placed inside the Meshes folder.
- Once imported, the model can be selected in the Project Window.

**Steps to import the character:**
1. Open the Unity project.
2. Find the Meshes folder.
3. Open the folder containing the downloaded character.
4. Drag the character file into the Meshes folder in Unity.
5. Select the imported character.
6. Open the Inspector to view its settings.

### 8. Setting Up the Character Rig
- The character rig helps Unity understand how the character is animated.
- The instructor changes the animation type to Humanoid.
- This allows the character to use a humanoid animation setup.

**Steps to change the rig:**
1. Select the imported character.
2. Open the Inspector.
3. Click the Rig tab.
4. Find Animation Type.
5. Change Generic to Humanoid.
6. Click Apply.

### 9. Setting Up Character Materials
- Imported characters may appear gray or white.
- This can happen when the character's materials are not configured.
- Materials control how the character's surface looks.
- The instructor changes the material settings to use the embedded materials.

**Steps to configure materials:**
1. Select the imported character.
2. Open the Materials tab in the Inspector.
3. Find Material Creation.
4. Select Standard (Legacy).
5. Choose Use Embedded Materials.
6. Click Apply.
7. Check whether the character's appearance is correct.
8. If Unity displays a normal map warning, use
opinion: I learned that the game development pipeline can help me turn my story ideas into an actual game by following an organized process. From the videos, I learned how to plan a game, create folders, write documentation, and use Unity to build a project. I also learned how to import custom characters and organize assets. I think this pipeline can help with my own space shooter game because I can use it to plan the story, organize my files, and keep track of what I need to work on. One question I have is how I can use this pipeline to add more story elements to my game without making the project too complicated.
gitTest: For this assignment, I tested my Git workflow using Visual Studio and GitHub. I made a change to my project, saved it, and checked that everything was working. After that, I committed my changes and pushed them to my GitHub repository. I opened GitHub to make sure my changes were uploaded correctly.

**Test Commit:** 0e29f05

**Result:** My Git workflow worked, and I was able to save, commit, and push my changes to GitHub.
access: For this assignment, I worked on setting up my GitHub repository for Week 12 using Visual Studio. I checked that I could access my project and repository. I am still working on making sure everything is connected correctly. I also need to confirm that my instructor has access to view my work and I am working solo.
questions: Since I am working solo, my main questions are about making sure I understand the mission and what I need to complete. I want to know what the main requirements are, how much work is expected, and when everything needs to be finished. I also want to make sure my GitHub repository is set up correctly and that my professor can access my work. Another question I have is whether I need to provide screenshots or commit history as proof of my progress.

# prepBoard
notes: My diagram shows how I understand the Git workflow for my CS110 Week 12 project. I start by creating or editing my project in Visual Studio. After that, I run and test it to make sure everything works. Then I save my changes and make a Git commit to record my progress. Next, I push my commits to GitHub so my work is available online. Finally, I check my repository to make sure everything uploaded correctly and that my professor can access it. Since I am working solo, I am responsible for completing and checking each step myself.

# pitch
understand: From what I understand, my job is to complete my Week 12 project using Visual Studio and GitHub. Since I am working solo, I am responsible for organizing my work, making changes, testing everything, and keeping track of my progress. I need to make sure my project works correctly and that I save and commit my changes to GitHub. The finish line for me is having a completed project that meets the assignment requirements, works properly, and can be accessed by my professor. I also want to make sure I have proof of my work through my GitHub commits.
offer: Since I am working solo, I bring my creativity, determination, and the programming skills I have learned so far in CS110. I can contribute by writing code, testing my project, fixing errors, and keeping everything organized in Visual Studio and GitHub. One of my strengths is that I don't give up easily when something doesn't work. I try to figure out what went wrong and learn from my mistakes. My main contribution will be making sure my project is completed, works correctly, and meets the assignment requirements.
limits:  I still need to improve my programming skills, especially when working on more complicated projects in Visual Studio. I want to get better at understanding code, fixing errors, and learning new ways to make my projects work more efficiently. I also want to learn more about game development using Unity and C#.  I want to improve my problem-solving skills and become more independent when working on bigger projects. I plan to keep practicing and researching anything I don't understand.
availability: 
Preferred contact: Discord
Contact on Discord. @rudbull1226 or Futzies.
tools: For my Week 12 project, I chose tools that will help me with programming, game development, and keeping my work organized.

Visual Studio: I will use Visual Studio to write, edit, test, and debug my C# code.

Unity: I will use Unity to work on my game development project, create game objects, and test how everything works together.

GitHub: I will use GitHub to store my project, track my progress, and make sure my professor can access my work.

Git: I will use Git to commit my changes and keep track of different versions of my project.

C#: I will use C# as my programming language because it works with Unity and helps me control how objects behave in my game.
aiTool: AI: ChatGPT
Task: Fix errors that are in my code.
Verification: I will put screenshots, as well as inform on the Readme.

# availability
notes: Contact on Discord. @rudbull1226 or Futzies.
contact: Discord

# aiPlan
name: ChatGPT
task: Fix errors that are in my code.
verify: I will put screenshots, as well as inform on the Readme.

# huddle
mission: Since I am working solo, I decided that my mission will be to create a simple 3D space shooter game using Unity and C#. The story will be about a spaceship pilot who has to survive waves of enemy ships while traveling through space. My main playable goal is to let the player control a spaceship, move around the screen, and shoot at enemies to earn points. I want to start with basic movement and shooting before adding more features. I will use Visual Studio to write my C# scripts and GitHub to save and track my progress. My goal is to create a working game that is fun to play while improving my programming and game development skills.
framework: Since I am working solo, I decided to use the ADD (Attribute-Driven Design) framework to guide my decisions while creating my 3D space shooter game in Unity. I chose this framework because it will help me focus on the most important parts of my game before adding more complicated features. My first priority will be creating a 3D spaceship that the player can control and use to shoot enemies. After that, I want to add enemy spaceships, collisions, a health system, and a score system. I will test each feature before moving on to the next one. Using this framework will help me stay organized, improve my C# programming skills, and make sure my game is playable and completed on time.
pipeline: Story goal · owner Me (solo) · 2026-11-10T12:45 to 2026-11-10T13:00 Pacific
Inputs / assets · owner Me (solo) · 2026-11-10T13:00 to 2026-11-10T13:30 Pacific
Build + configure · owner Me (solo) · 2026-11-10T13:30 to 2026-11-10T16:30 Pacific
Output / scene · owner Me (solo) · 2026-11-10T16:30 to 2026-11-10T17:30 Pacific
Test + handoff · owner Me (solo) · 2026-11-10T17:30 to 2026-11-10T19:30 Pacific
My production pipeline shows how I plan to create my 3D space shooter game using Unity and C#. Since I am working solo, I will be responsible for every stage of development. My goal is to create a playable game where the player controls a spaceship and shoots enemy ships. I will use Unity, Visual Studio, C#, and 3D models to build my project. My main tasks will be creating spaceship movement, shooting mechanics, enemies, and collisions. After completing these features, I will test the game to make sure everything works correctly. I will also use GitHub to save my progress. This plan will help me stay organized and complete my project one step at a time.
tech: Since I am working solo, I decided to use tools that will help me create my 3D space shooter game and keep everything organized.

1. **Unity (Game Engine):** I chose Unity because it supports 3D game development and gives me the tools to create spaceships, enemies, and environments.

2. **C# (Programming Language):** I chose C# because it works with Unity and allows me to program spaceship movement, shooting, enemy behavior, and collisions.

3. **Visual Studio (Code Editor):** I will use Visual Studio to write my C# scripts, find errors, and improve my code.

4. **Unity Packages:** I plan to use Unity's Input System for player controls and the built-in 3D physics system for detecting collisions.

5. **3D Assets:** I will start with basic 3D shapes for my spaceship and enemies. Later, I can add more detailed models, laser effects, and a space background.

6. **Git and GitHub (Version Control):** I will use Git and GitHub to save my progress, track changes, and make my project accessible to my professor.

Since I am working solo, I will be responsible for checking that all my tools, packages, and assets work correctly. I will test my C# scripts in Unity, check that my 3D models display properly, and make sure my GitHub repository stays updated. I chose these tools because they will help me build a playable 3D game while improving my programming skills.
code: Classes & components
Class | Responsibility | GameObject
PlayerController | MonoBehaviour, Rigidbody | Controls spaceship movement
PlayerShooting | MonoBehaviour | Fires laser projectiles
Laser | MonoBehaviour, Collider | Moves lasers and detects hits
EnemyController | MonoBehaviour, Collider | Controls enemy behavior
GameManager | MonoBehaviour | Tracks score and game state
PlayerHealth | MonoBehaviour | Tracks player health and damage

Variables / properties
Name : type | Value / purpose | Used by
moveSpeed | float | Spaceship movement speed
laserSpeed | float | Laser projectile speed
health | int | Player health
score | int | Player's points
damage | int | Damage from lasers
laserPrefab | GameObject | Laser object to spawn

f(x) · Functions
Function | Inputs → result | When called
MovePlayer() | PlayerController | Moves the spaceship
Shoot() | PlayerShooting | Creates laser projectiles
TakeDamage() | PlayerHealth | Reduces player health
OnTriggerEnter() | Laser | Detects laser collisions
AddScore() | GameManager | Adds points for destroyed enemies

Packages / using
Package / namespace | Why included | Tested
using UnityEngine; | Accesses Unity classes such as MonoBehaviour, Rigidbody, and GameObject | [ ]
using UnityEngine.InputSystem; | Allows me to use Unity's newer Input System for spaceship controls | [ ]
using UnityEngine.UI; | Allows me to create UI elements such as health bars | [ ]
using TMPro; | Allows me to display score and other text using TextMeshPro | [ ]
Unity Input System package | Handles keyboard and controller input | [ ]
Unity 3D Physics | Handles collisions and Rigidbody physics | [ ]
communication: Team check-ins
Description / contact / owner | When · Pacific | Agreed
Review my Unity project goals | 2026-11-11T19:21 | [x]
Check my C# code and progress | 2026-11-12T19:22 | [x]
Test spaceship movement and shooting | 2026-11-13T19:22 | [x]
Commit my progress to GitHub | 2026-11-14T19:23 | [x]
Review my project and assignment requirements | 2026-11-15T19:23 | [x]
reuse: Since I am working solo on my 3D space shooter game, I want to create things that I can reuse in future game development projects. Some things I can reuse are my C# scripts for player movement, shooting, enemy behavior, health, and scoring. I can also reuse my Unity project structure and some of the 3D models and effects I create. The code and assets I make myself will be my original work, but if I use anything from the Unity Asset Store or other websites, I will make sure to check the license and give credit when required. I will keep track of where my assets come from in my GitHub README, including the creator's name, source link, and license information. This will help me stay organized and make it easier to use my work in future games without having to start everything from scratch.
boardNotes: Since I am working solo, my huddle board shows the decisions I made for my 3D space shooter game. I decided to use Unity as my game engine, C# for programming, Visual Studio for writing my code, and GitHub for keeping track of my progress. My main goal is to create a playable game where the player controls a spaceship, shoots enemies, and earns points. I also decided to use the ADD framework to help me focus on the most important features first.

Since I don't have any teammates, there were no team disagreements. One decision I changed was switching my game from 2D to 3D because I wanted to take advantage of Unity's 3D features and challenge myself.

Some questions I still have are how detailed my 3D models should be, how many enemies I should include, and whether I will have enough time to add extra features like different weapons or levels. For now, I plan to focus on making the basic gameplay work before adding anything more complicated. I will keep my decisions and progress recorded in my GitHub README so I can look back at them while developing my game.

# pipelineBoard
notes: My production pipeline shows how I plan to create my 3D space shooter game using Unity and C#. Since I am working solo, I will be responsible for every stage of development. My goal is to create a playable game where the player controls a spaceship and shoots enemy ships. I will use Unity, Visual Studio, C#, and 3D models to build my project. My main tasks will be creating spaceship movement, shooting mechanics, enemies, and collisions. After completing these features, I will test the game to make sure everything works correctly. I will also use GitHub to save my progress. This plan will help me stay organized and complete my project one step at a time.

# codeTables

## 0
id: dc99a4d2-b60a-4f3d-833b-8b5f3552562b
title: Classes & components

### columns

#### 0
label: Class
type: text

#### 1
label: Responsibility
type: text

#### 2
label: GameObject
type: text

### rows

#### 0
0: PlayerController
1: MonoBehaviour, Rigidbody
2: Controls spaceship movement

#### 1
0: PlayerShooting
1: MonoBehaviour
2: Fires laser projectiles

#### 2
0: Laser
1: MonoBehaviour, Collider
2: Moves lasers and detects hits

#### 3
0: EnemyController
1: MonoBehaviour, Collider
2: Controls enemy behavior

#### 4
0: GameManager
1: MonoBehaviour
2: Tracks score and game state

#### 5
0: PlayerHealth
1: MonoBehaviour
2: Tracks player health and damage

## 1
id: abebc130-e60e-4b89-9d53-1d1db2d73a53
title: Variables / properties

### columns

#### 0
label: Name : type
type: text

#### 1
label: Value / purpose
type: text

#### 2
label: Used by
type: text

### rows

#### 0
0: moveSpeed
1: float
2: Spaceship movement speed

#### 1
0: laserSpeed
1: float
2: Laser projectile speed

#### 2
0: health
1: int
2: Player health

#### 3
0: score
1: int
2: Player's points

#### 4
0: damage
1: int
2: Damage from lasers

#### 5
0: laserPrefab
1: GameObject
2: Laser object to spawn

## 2
id: bc70c9c9-89ee-435e-9e43-6768e3aad06a
title: f(x) · Functions

### columns

#### 0
label: Function
type: text

#### 1
label: Inputs → result
type: text

#### 2
label: When called
type: text

### rows

#### 0
0: MovePlayer()
1: PlayerController
2: Moves the spaceship

#### 1
0: Shoot()
1: PlayerShooting
2: Creates laser projectiles

#### 2
0: TakeDamage()
1: PlayerHealth
2: Reduces player health

#### 3
0: OnTriggerEnter()
1: Laser
2: Detects laser collisions

#### 4
0: AddScore()
1: GameManager
2: Adds points for destroyed enemies

## 3
id: c4ce91e3-3214-4c93-a2a3-797e589120e0
title: Packages / using

### columns

#### 0
label: Package / namespace
type: text

#### 1
label: Why included
type: text

#### 2
label: Tested
type: checkbox

### rows

#### 0
0: using UnityEngine;
1: Accesses Unity classes such as MonoBehaviour, Rigidbody, and GameObject
2: false

#### 1
0: using UnityEngine.InputSystem;
1: Allows me to use Unity's newer Input System for spaceship controls
2: false

#### 2
0: using UnityEngine.UI;
1: Allows me to create UI elements such as health bars
2: false

#### 3
0: using TMPro;
1: Allows me to display score and other text using TextMeshPro
2: false

#### 4
0: Unity Input System package
1: Handles keyboard and controller input
2: false

#### 5
0: Unity 3D Physics
1: Handles collisions and Rigidbody physics
2: false

# communicationTables

## 0
id: a0b87b42-1615-4ce9-a50b-36346630578e
title: Team check-ins

### columns

#### 0
label: Description / contact / owner
type: text

#### 1
label: When · Pacific
type: datetime-local

#### 2
label: Agreed
type: checkbox

### rows

#### 0
0: Review my Unity project goals
1: 2026-11-11T19:21
2: true

#### 1
0: Check my C# code and progress
1: 2026-11-12T19:22
2: true

#### 2
0: Test spaceship movement and shooting
1: 2026-11-13T19:22
2: true

#### 3
0: Commit my progress to GitHub
1: 2026-11-14T19:23
2: true

#### 4
0: Review my project and assignment requirements
1: 2026-11-15T19:23
2: true

# huddleBoard
notes: My huddle board shows my plan for creating a 3D space shooter game in Unity. Since I am working solo, I am responsible for every part of the project. My mission is to create a playable game where the player controls a spaceship, shoots enemy ships, and earns points.

I will use Unity for the game engine, C# for programming, Visual Studio for writing my scripts, and GitHub to track my progress. I will start by creating the spaceship and its movement controls. After that, I will work on shooting, enemies, collisions, health, and scoring. I will test each feature before moving on to the next one.

My main priority is to make sure the basic gameplay works before adding extra features. I will record important decisions in my GitHub README and use commits to show my progress. Since I am working solo, there are no team disagreements, but I will review my decisions and make changes when needed.

# tasks

## 0
id: c5e11bf3-b3a0-4d88-982a-dd63ba902650
task: Project Documentation
owner: PERSON-F3FDB2D5B0A2C87741DC4C31
due: 2026-11-12T20:30
done: false
result: 

## 1
id: aff5deb9-7c82-45b2-8d3c-2a5601ef059b
task: Unity Project Setup
owner: PERSON-F3FDB2D5B0A2C87741DC4C31
due: 2026-11-12T20:30
done: false
result: 

## 2
id: 44fbc2e3-60e2-4d87-ba78-f289ee084440
task: Import 3D Player Spaceship
owner: PERSON-F3FDB2D5B0A2C87741DC4C31
due: 2026-11-12T20:30
done: false
result: 

## 3
id: baf10c63-9ac5-43b9-ad80-5b505fa5b54d
task: Create Player Movement
owner: PERSON-F3FDB2D5B0A2C87741DC4C31
due: 2026-11-12T20:30
done: false
result: 

## 4
id: ec3b58d6-c424-458b-9dbb-f35e138edb93
task: Test Player Controls
owner: PERSON-F3FDB2D5B0A2C87741DC4C31
due: 2026-11-12T20:30
done: false
result: 

## 5
id: 01e4d92d-6de5-49f6-9093-478c1c7fc284
task: GitHub Update and Handoff
owner: PERSON-F3FDB2D5B0A2C87741DC4C31
due: 2026-11-12T20:30
done: false
result: 

# reportA
checkpoint: Today, I worked on planning my Week 12 project and organizing everything I need to get started. Since I am working solo, I made all the decisions for my project. I decided to create a 3D space shooter using Unity and C# because I want to improve my game development and programming skills. I also chose the tools I will be using, created a production pipeline, planned my C# classes and functions, and assigned myself tasks with deadlines.

My biggest contribution today was creating a clear plan for how I want to build my game. I also identified what I still need to learn and what features I should focus on first. For Day B, my plan is to start working in Unity, set up my project, import my 3D spaceship, and begin testing the basic player controls. I will use Visual Studio to work on my C# scripts and GitHub to track my progress. My goal is to take everything I planned today and start turning it into a playable game.
evidence: For my Week 12A checkpoint, I successfully pushed my work to my GitHub repository. Since I am working solo, I am responsible for keeping my project organized and documenting my progress.

**GitHub Repository:**
https://github.com/rsierratrujillo4553-byte/cs110-week12

**Commit ID:** 577f99d

**Commit Link:**
https://github.com/rsierratrujillo4553-byte/cs110-week12/commit/577f99d

**Evidence Files:**
- 12A/Evidence/FORM-51426BF1736A124E5873680F.pdf
- 12A/Evidence/FORM-E8BEB08EE808039F84FB7550.pdf
- 12A/Evidence/PREP-5924A7036BB07FBF208B0CCB.pdf

My checkpoint shows that I uploaded my Week 12A evidence to GitHub. My project is a 3D space shooter that I plan to develop using Unity and C#. For Day B, I plan to continue working on my Unity project, import my 3D spaceship, and begin testing the player controls. Since I am working solo, I do not have a team repository link.
next: **My Next Task:** My next step is to start building my 3D space shooter game in Unity. I will set up my project, import my 3D spaceship, and begin working on the player movement using C# in Visual Studio.

**Deadline:** November 13, 2026. My goal is to have my Unity project set up, my spaceship imported, and the basic player controls ready for testing.

**Possible Blockers:** Some problems I might run into are errors in my C# scripts, problems importing my 3D spaceship, or issues getting the player movement to work correctly.

**Recovery Plan:** If I run into any problems, I will check Unity's Console for errors, review my code in Visual Studio, and research solutions. I will also test one feature at a time instead of trying to do everything at once. If I still can't figure something out, I will ask my professor for help.

Since I am working solo, I am responsible for completing these tasks and keeping track of my progress. I will continue using GitHub to save my work and document any important changes.

# reportABoard
notes: My checkpoint board shows what I accomplished during Week 12A of CS110. Today, I focused on planning my 3D space shooter game using Unity and C#. Since I am working solo, I made all the decisions for my project.

I completed my mission plan, chose my development tools, organized my production pipeline, planned my C# classes and functions, and assigned myself tasks with deadlines. I also documented my progress on GitHub with commit 577f99d.

For Day B, my next step is to set up my Unity project, import my 3D spaceship, and start working on player movement. I will test each feature before adding anything more complicated. My goal is to create a playable 3D space shooter while improving my programming skills.

# dayBReview
recap: I understand that my goal is to create a simple 3D space shooter using Unity and C#. Since I am working solo, I will be responsible for building the game, writing the code, testing everything, and keeping track of my progress on GitHub. My job is to follow the Unity tutorials through Video Six and use what I learn to start building my game. I want to focus on getting the spaceship to move and shoot before adding enemies, points, and other features. I still need to clarify how to make the shooting system work in 3D and how to set up enemy movement. I also need to make sure I understand how to test my game and submit my report, GitHub link, and public VIEW code correctly.
goal: true
owners: true
blockers: true
notes: Since I am working solo, I am responsible for completing all the tasks myself. My goal is still to create a simple 3D space shooter using Unity and C#. I need to focus on completing the tutorials through Video Six before adding more features to my game. I also need to make sure my spaceship movement and shooting work correctly. If I run into any problems with Unity or my C# scripts, I will troubleshoot them before moving forward. Once I finish, I will test my project, save my progress to GitHub, and make sure my report and submission requirements are completed.

# reportB
execution: I learned that the game development pipeline helps me stay organized while creating my own game. I worked on setting up my Unity project and organizing my scenes, scripts, materials, and prefabs. I also learned how documentation helps me keep track of my progress and plan what I want to add next. My goal is to use what I learned from the six videos to continue building my 3D game and make it more original. One thing I want to learn more about is how to add new gameplay features using C#.
tests: For Video 6, I worked on importing a custom 3D character into my Unity project. I learned how to organize character assets, configure a Humanoid rig, and replace the default player model. I also learned how prefabs work and why they are useful. I am testing my character to make sure the model, animations, and movement work correctly. If I encounter any errors, I will use the Unity Console to find the problem, make changes, and test again. My Unity project files will be my evidence of the work I completed.
handoff: I organized my Unity project so that my files are easier to find and open. My project includes folders for scenes, scripts, materials, and prefabs. I am following the six game development videos, and I am currently working on Video 6, which focuses on importing a custom player into Unity. My personal GitHub repository is https://github.com/rsierratrujillo4553-byte/cs110-week12. I am working individually, so I do not have a team link. To open my project, download the Unity project files, open Unity Hub, select Add Project, and choose the project folder. Once the project opens, load the main scene and press Play to test it. I am using my saved project files and GitHub repository as evidence of my progress.
reflection: While working on my Unity project, I learned how important it is to organize my files and understand how the game development pipeline works. I created a 3D Unity project and organized my scenes, scripts, materials, and prefabs. I also learned how to import custom characters and set up their rigs and materials from Video 6. My saved project files show the work I have completed so far. I am still working on making sure my custom character and its animations work correctly. My next step is to finish testing the player, fix any errors I find, and continue adding features to make the game my own. One useful thing I discovered is that using prefabs can save time because I can reuse objects instead of creating everything from scratch.

# reportBBoard
notes: This whiteboard shows the steps I followed while working on my Unity game for Week 12. I started by setting up my 3D project and organizing my scenes, scripts, materials, and prefabs. I am currently following Video 6, which teaches how to import a custom player and configure the character. My next step is to test the character's movement and animations, fix any problems, and test again. I am working individually, and this process helps me understand how to build and improve my game step by step.